const Pool= require('pg').Pool;
const pool =new Pool({
    user:'postgres',
    host:'localhost',
    database:'employees',
    password: 'root',
    port: 5432,
    pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
      }
});

module.exports=pool;