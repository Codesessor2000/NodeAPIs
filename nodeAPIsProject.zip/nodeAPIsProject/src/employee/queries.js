 const getEmployees="SELECT * FROM employees";
 const getEmployeeById="SELECT * FROM employees WHERE id=$1";
 const addEmployee="INSERT INTO employees(fullname,email,address,contact,gender) VALUES ($1,$2,$3,$4,$5)";
 const removeEmployee="DELETE FROM employees WHERE id=$1";
 const checkEmailExists="SELECT s FROM employees s WHERE s.email = $1";
 const editEmployee="UPDATE employees SET fullname=$1,email=$2,address=$3,contact=$4,gender=$5 WHERE id=$6";
 module.exports={
     getEmployees,
     getEmployeeById,
     checkEmailExists,
     addEmployee,
     removeEmployee,
     editEmployee,
 }