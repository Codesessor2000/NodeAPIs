const res = require('express/lib/response');
const pool = require('../../db');
const queries = require('./queries');
const getEmployees = (req, res) => {
    pool.query(queries.getEmployees, (error, results) => {
        if (error) throw error;
        res.status(200).json(results.rows);
    })
};
const getEmployeeById = (req, res) => {
    const id = parseInt(req.params.id);
    pool.query(queries.getEmployeeById, [id], (error, results) => {
        if (error) throw error;
        res.status(200).json(results.rows);
    })
};
const addEmployee = (req, res) => {
    const { fullname, email, address, contact, gender } = req.body;

    //check if email exists
    pool.query(queries.checkEmailExists, [email], (error, results) => {
        if (error) throw error;
        if (results.rows.length) {
            res.send("Email already Exists.");
        }
        pool.query(queries.addEmployee, [fullname, email, address, contact, gender], (error, results) => {
            if (error) throw error;
            res.status(201).send('Employee Created Successfuly');
            console.log('Student Created');
        });
    });
};
const removeEmployee = (req, res) => {
    const id = parseInt(req.params.id);
    pool.query(queries.getEmployeeById, [id], (error, results) => {
        const noEmployeeFound = !results.rows.length;
        if (noEmployeeFound) {
            res.send('There is No Entry of Employee in the Database');
        }
        pool.query(queries.removeEmployee, [id], (error, results) => {
            if (error) throw error;
            res.status(200).send("Employee Removed Successfully");
        })
    });
};
const editEmployee = (req, res) => {
    const id = parseInt(req.params.id);
    const { fullname, email, address, contact, gender } = req.body;

    pool.query(queries.getEmployeeById, [id], (error, results) => {
        const noEmployeeFound = !results.rows.length;
        if (noEmployeeFound) {
            res.send('There is No Entry of Employee in the Database');
        }
        pool.query(queries.editEmployee, [fullname,email, address, contact, gender, id], (error, results) => {
            if (error) throw error;
            res.status(200).send("Employee updated successfully");
        });
    });

};
module.exports = {
    getEmployees,
    getEmployeeById,
    addEmployee,
    removeEmployee,
    editEmployee,
}