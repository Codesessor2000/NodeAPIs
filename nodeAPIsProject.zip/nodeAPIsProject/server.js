const express = require('express');
const employeeRoutes = require('./src/employee/routes');
const bodyParser = require("body-parser");
const cors = require("cors");
const app = express();
const port = process.env.PORT || 8080;
var corsOptions = {origin: "http://localhost:8081"};
app.use(cors(corsOptions));
// parse requests of content-type - application/json
app.use(bodyParser.json());
// parse requests of content-type - application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

app.get("/", (req, res) => {
    res.send("Hello Word!!!");
});

app.use('/api/v1/employees', employeeRoutes);

app.listen(port, () => console.log(`app listening on port ${port}`));